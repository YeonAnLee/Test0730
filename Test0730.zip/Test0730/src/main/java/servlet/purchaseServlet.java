package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import dao.InformationDto;
import dao.LoginDao;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet("/purchaseServlet")
public class purchaseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json; charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        // 세션에서 member_id 가져오기
        String member_id = (String) session.getAttribute("member_id");
        int price = Integer.parseInt(request.getParameter("price"));
        String contentName = request.getParameter("contentName");

        LoginDao ldao = new LoginDao();
        ArrayList<InformationDto> memberList = ldao.information(member_id);

        if (!memberList.isEmpty()) {
            InformationDto member = memberList.get(0);
            int currentPoints = member.getPoint();

            if (currentPoints >= price) {
                // 포인트 차감
                member.setPoint(currentPoints - price);
                ldao.updateInformation(member_id, member.getPoint());

                // JSON 응답 작성
                out.print("{\"success\":true,\"message\":\"컨텐츠(" + contentName + ")를 구입하였습니다.\",\"updatedInfo\":\"" + member.getName() + "(" + member_id + ")님 안녕하세요  <br>포인트 : " + member.getPoint() + "점\"}");
            } else {
                // 포인트 부족
                out.print("{\"success\":false,\"message\":\"포인트가 부족합니다. 광고를 클릭하세요.\"}");
            }
        } else {
            out.print("{\"success\":false,\"message\":\"회원 정보를 찾을 수 없습니다.\"}");
        }

        out.flush();
    }
}
