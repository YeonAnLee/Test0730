package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import dao.LoginDao;
import dao.InformationDto;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;

@WebServlet("/randomPointServlet")
public class RandomPointServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json; charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        // 세션에서 member_id 가져오기
        String member_id = (String) session.getAttribute("member_id");
        LoginDao ldao = new LoginDao();
        ArrayList<InformationDto> memberList = ldao.information(member_id);

        if (!memberList.isEmpty()) {
            InformationDto member = memberList.get(0);
            Random rand = new Random();
            int additionalPoints = rand.nextInt(1000) + 1;
            // 포인트 추가
            member.setPoint(member.getPoint() + additionalPoints);
            ldao.updateInformation(member_id, member.getPoint());

            // JSON 응답 작성
            out.print("{\"success\":true,\"message\":\"" + additionalPoints + " 포인트를 얻었습니다!\",\"updatedInfo\":\"" + member.getName() + "(" + member_id + ")님 안녕하세요<br>포인트 : " + member.getPoint() + "점\"}");
        } else {
            out.print("{\"success\":false,\"message\":\"회원 정보를 찾을 수 없습니다.\"}");
        }
        
        out.flush();
    }
}
