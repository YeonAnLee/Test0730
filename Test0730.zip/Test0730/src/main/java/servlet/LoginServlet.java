package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;

import dao.LoginDao;

@WebServlet("/LoginServlet1")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
    	response.setContentType("text/html;charset=UTF-8");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String member_id = null;
		try {
		LoginDao ldao = new LoginDao();
		member_id = ldao.login(id, pw);
		} catch(SQLException e) {
			e.printStackTrace();
		}
		System.out.println(member_id);
		  if (member_id == null) {
	            System.out.println("로그인 실패.");
	            request.setAttribute("loginError", true); 
	            RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
	            rd.forward(request, response);
	        } else if (member_id.equals("admin")) {
	            response.sendRedirect("/Test0730/adminServlet");
	        } else {
	            System.out.println("로그인 성공.");
	            HttpSession hs = request.getSession();
	            hs.setAttribute("member_id", member_id);
	            response.setContentType("text/html;charset=UTF-8");
	            response.getWriter().println("<html>");
	            response.getWriter().println("<head>");
	            response.getWriter().println("<title>로그인 성공</title>");
	            response.getWriter().println("<meta http-equiv='refresh' content='1;url=/Test0730/main.jsp'>");
	            response.getWriter().println("<script type='text/javascript'>"); 
	            response.getWriter().println("alert('로그인 되었습니다.');");
	            response.getWriter().println("</script>");
	            response.getWriter().println("</head>");
	            response.getWriter().println("<body></body>");
	            response.getWriter().println("</html>");
	        }
	}
}
