package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

	public class MemberInfoDao {
		private static final String driver = "oracle.jdbc.driver.OracleDriver";
	    private static final String url = "jdbc:oracle:thin:@localhost:1521:xe";
	    private static final String db_id = "Test";
	    private static final String db_pw = "1234";
	  
	    public ArrayList<MemberInfoDto> memberInfo(String id, String pw) throws SQLException  {
	    	String member_id = null;
	        try {
				Class.forName(driver);
				
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}
	       
	        String sql = 
	        		"SELECT id FROM member WHERE id = ? AND pw = ?";
	        
	        PreparedStatement pstmt;
			try {
				Connection conn = DriverManager.getConnection(url, db_id, db_pw);
				pstmt = conn.prepareStatement(sql); 
				pstmt.setString(1, id);
				pstmt.setString(2, pw);
				ResultSet rs = pstmt.executeQuery();
	        try {
				if(rs.next()) {
					member_id = rs.getString("id");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
	        rs.close();
	        pstmt.close();
	        conn.close();
	        
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return member_id;
	    }

}
