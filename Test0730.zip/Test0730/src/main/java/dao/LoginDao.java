package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Servlet.Ticket_checkDto;
import jakarta.servlet.http.HttpSession;

public class LoginDao {
	private static final String driver = "oracle.jdbc.driver.OracleDriver";
    private static final String url = "jdbc:oracle:thin:@localhost:1521:xe";
    private static final String db_id = "Test";
    private static final String db_pw = "1234";
    public static void main(String[] args) throws SQLException {
    	LoginDao ldao = new LoginDao();
    	System.out.println(ldao.login("wnsdud893", "1234"));
    	System.out.println(ldao.join("회원2", "1234", "이준영"));
    	
    }
    public String login(String id, String pw) throws SQLException  {
    	String member_id = null;
        try {
			Class.forName(driver);
			
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
       
        String sql = 
        		"SELECT id FROM member WHERE id = ? AND pw = ?";
        
        PreparedStatement pstmt;
		try {
			Connection conn = DriverManager.getConnection(url, db_id, db_pw);
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			ResultSet rs = pstmt.executeQuery();
        try {
			if(rs.next()) {
				member_id = rs.getString("id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
        rs.close();
        pstmt.close();
        conn.close();
        
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return member_id;
    }
    
    public int join(String name, String pw, String id) {
    	int rs = 0;
        try {
			Class.forName(driver);
			
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
       
        String sql = 
        		"INSERT INTO member (id, pw, name) VALUES (?, ?, ?)";
        
        PreparedStatement pstmt;
		try {
			Connection conn = DriverManager.getConnection(url, db_id, db_pw);
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, name);
			rs = pstmt.executeUpdate();
        
			if(rs != 0) {
				System.out.println("회원가입됨.");
			}
		
	        pstmt.close();
	        conn.close();
	        
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return rs;
    }
    
    public ArrayList<InformationDto> information(String id) {
    	ArrayList<InformationDto> list = new ArrayList<>();
        try {
			Class.forName(driver);
			
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
       
        String sql = 
        		"SELECT name, point FROM member WHERE id = ?";
        
        PreparedStatement pstmt;
		try {
			Connection conn = DriverManager.getConnection(url, db_id, db_pw);
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
        
			if(rs.next()) {
				System.out.println("정보있음");
				String name = rs.getString(1);
				int point = rs.getInt(2);
				InformationDto InformationDto = new InformationDto(name, point);
	            list.add(InformationDto);	
			}
		
	        pstmt.close();
	        conn.close();
	        
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return list;
    }
    
    public void updateInformation(String id, int newPoint) {
        String sql = "UPDATE member SET point = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, db_id, db_pw);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, newPoint);
            pstmt.setString(2, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
